# Introduction to machine learning
This repository consists of basic introduction of python and machine learning. It consists of the below codes and study materials.
<ul>
  <li>Introduction to Machine Learning</li>
  <li>Machine Learning Applications</li>
  <li>Hands on experience with Python</li>
  <ul>
    <li> [Installing Python](https://github.com/robaita/introduction_to_machine_learning/blob/main/Python_Installation.md) </li>
  </ul>
 </ul>
<hr> 
<ul>
  <li>Mathematics behind Machine Learning</li>
  <li>Linear Algebra</li>
  <li>Face Recognition Implementation - from scratch</li>
 </ul>
 <hr> 
<ul>
  <li>Introduction to Artificial Neural Network</li>
  <li>Face Recognition with ANN</li>
 </ul>
